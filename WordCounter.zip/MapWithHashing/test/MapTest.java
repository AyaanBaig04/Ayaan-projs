import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.map.Map;
import components.map.Map.Pair;

/**
 * JUnit test fixture for {@code Map<String, String>}'s constructor and kernel
 * methods.
 *
 * @author Put your name here
 *
 */
public abstract class MapTest {

    /**
     * Invokes the appropriate {@code Map} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new map
     * @ensures constructorTest = {}
     */
    protected abstract Map<String, String> constructorTest();

    /**
     * Invokes the appropriate {@code Map} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new map
     * @ensures constructorRef = {}
     */
    protected abstract Map<String, String> constructorRef();

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the implementation
     * under test type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsTest = [pairs in args]
     */
    private Map<String, String> createFromArgsTest(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorTest();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the reference
     * implementation type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsRef = [pairs in args]
     */
    private Map<String, String> createFromArgsRef(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorRef();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    @Test
    public final void constructorTest_1() {
        Map<String, String> s = this.createFromArgsTest();
        Map<String, String> sExpected = this.createFromArgsRef();

        assertEquals(sExpected, s);
    }

    @Test
    public final void constructorTest_2() {
        Map<String, String> s = this.createFromArgsTest("0", "zero", "1", "one",
                "2", "two", "3", "three");
        Map<String, String> sExpected = this.createFromArgsRef("0", "zero", "1",
                "one", "2", "two", "3", "three");

        assertEquals(sExpected, s);
    }

    @Test
    public final void addTest_1() {
        Map<String, String> s = this.createFromArgsTest("color", "red",
                "animal", "dog");
        Map<String, String> sExpected = this.createFromArgsRef("color", "red",
                "animal", "dog");

        s.add("", "");
        sExpected.add("", "");

        assertEquals(sExpected, s);
        assertEquals(sExpected.size(), s.size());

    }

    @Test
    public final void addTest_2() {
        Map<String, String> s = this.createFromArgsTest("0", "zero", "1", "one",
                "2", "two", "3", "three", "4", "four");
        Map<String, String> sExpected = this.createFromArgsRef("0", "zero", "1",
                "one", "2", "two", "3", "three", "4", "four");

        s.add("5", "five");
        sExpected.add("5", "five");

        assertEquals(sExpected, s);
        assertEquals(sExpected.size(), s.size());

    }

    @Test
    public final void removeTest_1() {
        Map<String, String> s = this.createFromArgsTest("zero", "0", "one", "1",
                "two", "2", "three", "3", "four", "4", "five", "5");
        Map<String, String> sExpected = this.createFromArgsRef("zero", "0",
                "one", "1", "two", "2", "three", "3", "four", "4", "five", "5");

        Pair<String, String> tVal = s.remove("three");
        Pair<String, String> eVal = sExpected.remove("three");

        assertEquals(eVal, tVal);
        assertEquals(sExpected.size(), s.size());
        assertEquals(sExpected, s);
    }

    @Test
    public final void removeTest_2() {
        Map<String, String> s = this.createFromArgsTest("zero", "0", "one", "1",
                "two", "2", "three", "3", "four", "4", "five", "5");
        Map<String, String> sExpected = this.createFromArgsRef("zero", "0",
                "one", "1", "two", "2", "three", "3", "four", "4", "five", "5");

        Pair<String, String> tVal = s.remove("five");
        Pair<String, String> eVal = sExpected.remove("five");

        assertEquals(eVal, tVal);
        assertEquals(sExpected.size(), s.size());
        assertEquals(sExpected, s);
    }

    @Test
    public void removeAny_1() {

        Map<String, String> s = this.createFromArgsTest("zero", "0", "one", "1",
                "two", "2", "three", "3", "four", "4", "five", "5");
        Map<String, String> sExpected = this.createFromArgsRef("zero", "0",
                "one", "1", "two", "2", "three", "3", "four", "4", "five", "5");

        s.removeAny();
        sExpected.removeAny();

        assertEquals(sExpected.size(), s.size());
    }

    @Test
    public void removeAny_2() {

        Map<String, String> s = this.createFromArgsTest("zero", "0", "one",
                "1");
        Map<String, String> sExpected = this.createFromArgsRef("zero", "0",
                "one", "1");

        s.removeAny();
        sExpected.removeAny();

        assertEquals(sExpected.size(), s.size());
    }

    @Test
    public void valueTest_1() {
        Map<String, String> test = this.createFromArgsTest("", "empty");
        Map<String, String> expected = this.createFromArgsRef("", "empty");
        String tVal = test.value("");
        String eVal = expected.value("");

        assertEquals(eVal, tVal);
    }

    @Test
    public void valueTest_2() {
        Map<String, String> s = this.createFromArgsTest("0", "zero", "1", "one",
                "2", "two", "3", "three", "4", "four");
        Map<String, String> sExpected = this.createFromArgsRef("0", "zero", "1",
                "one");

        String tVal = s.value("1");
        String eVal = sExpected.value("1");

        assertEquals(eVal, tVal);
    }

    @Test
    public void hasKeyTest_1() {
        Map<String, String> test = this.createFromArgsTest();
        Map<String, String> expected = this.createFromArgsRef();

        boolean tVal = test.hasKey("key");
        boolean eVal = expected.hasKey("key");

        assertEquals(eVal, tVal);
    }

    @Test
    public void hasKeyTest_2() {
        Map<String, String> s = this.createFromArgsTest("0", "zero", "1", "one",
                "2", "two", "3", "three", "4", "four");
        Map<String, String> sExpected = this.createFromArgsRef("0", "zero", "1",
                "one", "2", "two", "3", "three", "4", "four");

        boolean tVal = s.hasKey("1");
        boolean eVal = sExpected.hasKey("1");

        assertEquals(eVal, tVal);
    }

    @Test
    public void sizetest_1() {
        Map<String, String> test = this.createFromArgsTest();
        Map<String, String> expected = this.createFromArgsRef();

        assertEquals(test.size(), expected.size());
    }

    @Test
    public void sizetest_2() {
        Map<String, String> s = this.createFromArgsTest("0", "zero", "1", "one",
                "2", "two", "3", "three", "4", "four");
        Map<String, String> sExpected = this.createFromArgsRef("0", "zero", "1",
                "one", "2", "two", "3", "three", "4", "four");

        assertEquals(s.size(), sExpected.size());
    }

}
